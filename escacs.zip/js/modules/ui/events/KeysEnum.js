export const KEYS = {
    NONE: "",
    ESCAPE: "Escape",
    i: "i"
}