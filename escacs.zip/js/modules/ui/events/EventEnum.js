export const KEY_EVENTS = {
    KEYDOWN: "keydown",
    KEYUP: "keyup"
}

export const MOUSE_EVENTS = {
    CLICK: "click",
    WHEELUP: "wheelup",
    WHEELDOWN: "wheeldown"
}