


export class UIManager{
    
    constructor(){
        
    }
}