export const MODES = {
    NORMAL_MATCH: "NORMAL_MATCH",
    TEST_MODE: "TESTING_MODE"
}

export const DISPLAY_NAMES_EN = {
    NORMAL_MATCH: "Normal Match",
    TEST_MODE: "Testing Mode"
}